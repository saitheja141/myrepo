User can pass in input(tweets) in the below format using cli
=======================================================
Sample input:-

World's best cricketer is #Sachin
World's best captain is #Dhoni
World's best cricketer is #Sachin
World's best opener  is #Sehwag
World's best cricketer is #Sachin
World's best cricketer is #Sachin
World's best cricketer is #Sachin
World's best captain is #Dhoni
done

Sample output:-

Top 10 trending hashtags
#Sachin
#Dhoni
#Sehwag