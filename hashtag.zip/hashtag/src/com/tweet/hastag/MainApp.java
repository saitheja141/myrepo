package com.tweet.hastag;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MainApp {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		try
		{
		List<String> lst=new ArrayList<>();
		/* Input will read tweets until user types done **/
		 while(input.hasNext("done")) {
	       lst.add(input.next());
		}
		 /*passing list of tweets*/
		 printTopTenHashtags(lst);
		}catch(Exception exception)
		{
			System.out.println(exception.getMessage());
		}
		finally
		{
			input.close();
		}
}
    /**
     * Method which prints top 10 trending tags
     * @param lst
     */
	private static void printTopTenHashtags(List<String> lst) {
		/*Map data structure to store Hashtag  along with their count*/
		Map<String,Integer> map=new HashMap<>();
		String hashTag="";
		for(String tweet:lst) {
	       if(tweet!=null && tweet.length()>0){
	        hashTag=tweet.substring(tweet.lastIndexOf('#')+1).toLowerCase();
	        if(map.containsKey(hashTag))
	         map.put(hashTag,map.get(hashTag)+1);
	        else
	        	map.put(hashTag,1);
	       }
		 }
	
		 /* using Comparator interface to perform sorting based on 
		  * key if keys are same then we take sorting  based on value*/
	       Map<String,Integer> resultMap=map.entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByValue().reversed().thenComparing(Map.Entry.<String,Integer>comparingByKey()))
	    		                                   .collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue,(k,v)->k,LinkedHashMap::new));
	       System.out.println("Top 10 trending hashtags");
	       resultMap.forEach((key,value)-> System.out.println(key));
	  }
	}
